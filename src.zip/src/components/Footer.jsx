import React from 'react'

const Footer = () => {
  return (
    <footer>
        Designed by Ajendra Sharma
    </footer>
  )
}

export default Footer
